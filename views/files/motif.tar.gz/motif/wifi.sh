#!/bin/sh
killall wpa_supplicant
wpa_passphrase $1 $2 > /userdata/cfg/wpa_supplicant.conf
wpa_supplicant -B -i wlan0 -c /userdata/cfg/wpa_supplicant.conf

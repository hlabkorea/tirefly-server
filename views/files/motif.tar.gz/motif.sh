#!/bin/sh
cd /opt/motif/bin
./motif &
